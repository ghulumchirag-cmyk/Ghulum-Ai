package com.ghulumai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.BitmapFactory
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val PICK_IMAGE = 101
    // Replace with YOUR secure backend endpoint. Do not put provider secret keys in the APK.
    private val API_ENDPOINT = "https://YOUR-BACKEND.example/generate"
    private var imageUri: Uri? = null
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var prompt: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF10111A.toInt())
        }
        fun label(text: String, size: Float) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(label("GHULUM AI", 30f))
        root.addView(label("PHOTO → MOTION VIDEO", 14f))
        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF292B3A.toInt())
        }
        root.addView(preview, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { setMargins(0, 22, 0, 16) })

        val choose = Button(this).apply {
            text = "📷  फोटो चुनें"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                startActivityForResult(intent, PICK_IMAGE)
            }
        }
        root.addView(choose, matchWidth())

        prompt = EditText(this).apply {
            hint = "Motion लिखें: dance, walk, cinematic..."
            setHintTextColor(0xFFBBBBCC.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(false)
            minLines = 2
            setPadding(12, 8, 12, 8)
        }
        root.addView(prompt, matchWidth())

        val generate = Button(this).apply {
            text = "✨  वीडियो बनाएं"
            setOnClickListener { generateVideo() }
        }
        root.addView(generate, matchWidth())
        status = label("पहले फोटो चुनें। AI generation के लिए backend API आवश्यक है।", 13f)
        status.setPadding(0, 14, 0, 0)
        root.addView(status, matchWidth())
        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 8, 0, 8) }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                imageUri = uri
                contentResolver.openInputStream(uri)?.use {
                    preview.setImageBitmap(BitmapFactory.decodeStream(it))
                }
                status.text = "फोटो चुनी गई। अब motion लिखें और Generate दबाएं।"
            }
        }
    }

    private fun generateVideo() {
        if (imageUri == null) {
            status.text = "पहले गैलरी से फोटो चुनें।"
            return
        }
        if (API_ENDPOINT.contains("YOUR-BACKEND")) {
            status.text = "Demo UI तैयार है। असली वीडियो के लिए README में बताए अनुसार backend API जोड़ें।"
            return
        }
        status.text = "Request भेजी जा रही है..."
        // Generic backend contract. Adapt multipart field names and response parsing to your provider.
        thread {
            try {
                val boundary = "GhulumAiBoundary${System.currentTimeMillis()}"
                val connection = (URL(API_ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = 20000
                    readTimeout = 60000
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                }
                connection.outputStream.use { out ->
                    fun write(s: String) = out.write(s.toByteArray(Charsets.UTF_8))
                    write("--$boundary\r\nContent-Disposition: form-data; name=\"prompt\"\r\n\r\n${prompt.text}\r\n")
                    write("--$boundary\r\nContent-Disposition: form-data; name=\"image\"; filename=\"photo.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n")
                    contentResolver.openInputStream(imageUri!!)?.use { it.copyTo(out) }
                    write("\r\n--$boundary--\r\n")
                }
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                runOnUiThread { status.text = "Backend response: $response" }
                connection.disconnect()
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error: ${e.message ?: "Request failed"}" }
            }
        }
    }
}
