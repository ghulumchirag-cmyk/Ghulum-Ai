# GHULUM AI — Android starter project

यह Android Studio का शुरुआती प्रोजेक्ट है। इसमें फोटो चुनने, motion prompt लिखने और configured backend API को request भेजने का UI है।

## ज़रूरी बात
यह प्रोजेक्ट अपने-आप AI वीडियो नहीं बनाता। असली वीडियो बनाने के लिए आपको किसी वैध image-to-video AI provider का backend/API जोड़ना होगा। इस starter में API endpoint placeholder है, इसलिए बिना backend configure किए Generate दबाने पर demo सूचना दिखेगी। कोई free provider हमेशा मुफ्त या बिना limit के उपलब्ध होगा, इसकी गारंटी नहीं है।

## APK कैसे बनाएं
1. Android Studio में यह प्रोजेक्ट खोलें।
2. Gradle sync पूरा होने दें।
3. `app/src/main/java/com/ghulumai/MainActivity.kt` में `API_ENDPOINT` को अपने backend endpoint से बदलें।
4. Backend को चुनी हुई image-to-video service से जोड़ें; API secret को APK में hard-code न करें।
5. Build > Build APK(s) चुनें। बनी हुई APK `app/build/outputs/apk/` में मिलेगी।

## Backend API अपेक्षा
POST multipart/form-data:
- `image`: selected image file
- `prompt`: motion description
Expected JSON response: `{ "videoUrl": "https://.../result.mp4" }`

यह एक starter project है, production-ready app नहीं। Backend में authentication, upload limits, privacy controls, error handling और provider terms लागू करें।
